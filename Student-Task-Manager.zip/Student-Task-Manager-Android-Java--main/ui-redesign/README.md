# UI Redesign: colours, font and interface

Drop-in replacement for the app's look and feel. **No Java changes are needed:**
every view ID used by the Java code is unchanged (`recyclerViewTasks`, `fabAdd`,
`textViewEmpty`, `editTextTitle`, `buttonSave`, and so on).

![Preview](preview.png)

## What changed

| Area | Before | After |
|---|---|---|
| Palette | Default Material purple + teal | Indigo `#5B5BD6` with coral `#FF7A59` accent, soft `#F4F5FB` background |
| Font | System default | **Poppins** (Regular, Medium, SemiBold, Bold), bundled in `res/font/` |
| Header | Flat purple toolbar | Gradient header with rounded bottom corners and a subtitle |
| Task cards | Plain card with floating icons | Rounded 20dp cards, coral accent bar, round tinted Edit / Delete buttons |
| Empty state | Grey text | Clipboard illustration + message |
| Forms | Bare fields | Fields inside a rounded card, 14dp rounded outlines, indigo focus colour, 56dp button |
| Splash | Plain background | Gradient, glowing logo badge, new tagline |
| FAB | Teal | Coral, larger, with soft shadow |
| Dark mode | Not styled | Full dark palette in `values-night/colors.xml` (automatic) |
| Dialogs | Default | Rounded delete-confirmation dialog, Poppins buttons |

## Install (Android Studio)

1. Copy everything inside `ui-redesign/res/` into your app's `app/src/main/res/`,
   merging folders. Allow it to overwrite `colors.xml` and `themes.xml`; keep your
   existing `strings.xml`.
2. In `app/build.gradle`, make sure these are present:
   ```gradle
   implementation 'com.google.android.material:material:1.9.0'   // or newer
   implementation 'androidx.constraintlayout:constraintlayout:2.1.4'
   ```
   `minSdk` 21 or higher works. Poppins is a bundled font, so there is no network
   dependency.
3. In `AndroidManifest.xml`, keep your existing theme entries:
   `Theme.StudentTaskManager` on the `<application>` and
   `Theme.StudentTaskManager.NoActionBar` on activities. Both still exist.
4. Sync Gradle and run. Toggle system dark mode to see the dark palette.

If `ic_add`, `ic_edit`, `ic_delete`, `ic_logo` or `splash_background` already exist
in your `res/drawable/`, overwrite them with the versions here.

## Customising

Change the whole look from one file, `res/values/colors.xml`:

- `colorPrimary` and `gradient_start` / `gradient_end`: header and buttons
- `colorAccent`: FAB and the card accent bar
- Change fonts by swapping the files in `res/font/` and updating `poppins.xml`

## Notes

- Poppins is licensed under the SIL Open Font License (see `FONT_LICENSE_OFL.txt`),
  which allows bundling it in apps.
- The preview image is a design mock rendered from the same colours, fonts and
  dimensions as the XML. I could not run the Android emulator here, so check
  spacing on a real device or the emulator and tweak `dp` values if needed.
