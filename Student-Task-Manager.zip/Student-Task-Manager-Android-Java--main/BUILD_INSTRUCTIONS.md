# Student Task Manager - Step-by-Step Build Instructions

## 📋 PREREQUISITES

Before starting, ensure you have:
1. ✅ **Android Studio** (Latest version recommended)
   - Download: https://developer.android.com/studio
2. ✅ **Java Development Kit (JDK 11+)**
   - Bundled with Android Studio
3. ✅ **Android SDK** (Installed via Android Studio)
4. ✅ **Android Virtual Device (AVD)** or Physical Android Device

---

## 🚀 STEP-BY-STEP IMPLEMENTATION

### STEP 1: Create New Android Project (5 minutes)

1. Open Android Studio
2. Click **"New Project"**
3. Select **"Empty Activity"**
4. Configure project:
   - **Name:** Student Task Manager
   - **Package name:** com.example.studenttaskmanager
   - **Save location:** Choose your preferred folder
   - **Language:** Java ⚠️ (NOT Kotlin)
   - **Minimum SDK:** API 21: Android 5.0 (Lollipop)
5. Click **"Finish"**
6. Wait for Gradle to sync

---

### STEP 2: Add Dependencies (3 minutes)

1. Open **`app/build.gradle`** (Module: app)
2. Find the `dependencies` section
3. Add these lines:

```gradle
dependencies {
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.9.0'
    implementation 'androidx.constraintlayout:constraintlayout:2.1.4'
    implementation 'androidx.cardview:cardview:1.0.0'
    implementation 'androidx.recyclerview:recyclerview:1.3.0'
    
    // Testing (optional)
    testImplementation 'junit:junit:4.13.2'
    androidTestImplementation 'androidx.test.ext:junit:1.1.5'
    androidTestImplementation 'androidx.test.espresso:espresso-core:3.5.1'
}
```

4. Click **"Sync Now"** at the top
5. Wait for Gradle to download dependencies

---

### STEP 3: Create Java Classes (30 minutes)

#### 3.1 Create TaskModel.java

1. Right-click on **com.example.studenttaskmanager** package
2. Select **New → Java Class**
3. Name: **TaskModel**
4. Copy code from **`TaskModel_PSEUDOCODE.java`** (provided in guide)

#### 3.2 Create DBHelper.java

1. Right-click on package → **New → Java Class**
2. Name: **DBHelper**
3. Copy code from **`DBHelper_PSEUDOCODE.java`**

#### 3.3 Create TaskAdapter.java

1. Right-click on package → **New → Java Class**
2. Name: **TaskAdapter**
3. Copy code from **`TaskAdapter_PSEUDOCODE.java`**

#### 3.4 Create SplashActivity.java

1. Right-click on package → **New → Activity → Empty Activity**
2. Name: **SplashActivity**
3. Uncheck "Generate Layout File" (we'll create XML manually)
4. Copy code from **`SplashActivity_PSEUDOCODE.java`**

#### 3.5 Keep MainActivity.java (Already created)

1. Replace content with code from **`MainActivity_PSEUDOCODE.java`**

#### 3.6 Create AddTaskActivity.java

1. Right-click on package → **New → Activity → Empty Activity**
2. Name: **AddTaskActivity**
3. Copy code from **`AddTaskActivity_PSEUDOCODE.java`**

#### 3.7 Create UpdateTaskActivity.java

1. Right-click on package → **New → Activity → Empty Activity**
2. Name: **UpdateTaskActivity**
3. Copy code from **`UpdateTaskActivity_PSEUDOCODE.java`**

---

### STEP 4: Create XML Layouts (30 minutes)

Navigate to: **res → layout**

#### 4.1 Create activity_splash.xml

1. Right-click on **layout** folder → **New → Layout Resource File**
2. File name: **activity_splash**
3. Root element: **androidx.constraintlayout.widget.ConstraintLayout**
4. Copy XML from **`activity_splash_LAYOUT.xml`**

#### 4.2 Modify activity_main.xml

1. Open existing **activity_main.xml**
2. Replace all content with **`activity_main_LAYOUT.xml`**

#### 4.3 Create task_item.xml

1. Right-click on **layout** → **New → Layout Resource File**
2. File name: **task_item**
3. Root element: **com.google.android.material.card.MaterialCardView**
4. Copy XML from **`task_item_LAYOUT.xml`**

#### 4.4 Create activity_add_task.xml

1. Right-click on **layout** → **New → Layout Resource File**
2. File name: **activity_add_task**
3. Copy XML from **`activity_add_task_LAYOUT.xml`**

#### 4.5 Create activity_update_task.xml

1. Right-click on **layout** → **New → Layout Resource File**
2. File name: **activity_update_task**
3. Copy XML from **`activity_update_task_LAYOUT.xml`**

---

### STEP 5: Create Drawable Resources (15 minutes)

Navigate to: **res → drawable**

#### 5.1 Create ic_add.xml (FAB icon)

1. Right-click on **drawable** → **New → Vector Asset**
2. Click on **Clip Art** icon
3. Search for **"add"**
4. Select the **plus/add icon**
5. Name: **ic_add**
6. Click **Next → Finish**

#### 5.2 Create ic_edit.xml

1. Right-click on **drawable** → **New → Vector Asset**
2. Search for **"edit"**
3. Select the **pencil/edit icon**
4. Name: **ic_edit**
5. Click **Next → Finish**

#### 5.3 Create ic_delete.xml

1. Right-click on **drawable** → **New → Vector Asset**
2. Search for **"delete"**
3. Select the **trash/delete icon**
4. Name: **ic_delete**
5. Click **Next → Finish**

#### 5.4 Create splash_background.xml

1. Right-click on **drawable** → **New → Drawable Resource File**
2. File name: **splash_background**
3. Root element: **shape**
4. Add this content:

```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android">
    <gradient
        android:startColor="#6200EE"
        android:endColor="#3700B3"
        android:angle="135" />
</shape>
```

#### 5.5 Create ic_logo.xml (Optional - Simple placeholder)

1. Right-click on **drawable** → **New → Vector Asset**
2. Search for **"assignment"** or **"task"**
3. Name: **ic_logo**
4. Click **Next → Finish**

---

### STEP 6: Update Resource Files (10 minutes)

#### 6.1 Update colors.xml

1. Open **res → values → colors.xml**
2. Replace with:

```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="colorPrimary">#6200EE</color>
    <color name="colorPrimaryDark">#3700B3</color>
    <color name="colorAccent">#03DAC5</color>
    
    <color name="white">#FFFFFF</color>
    <color name="black">#000000</color>
    <color name="grey">#757575</color>
    <color name="light_grey">#E0E0E0</color>
    
    <color name="red">#F44336</color>
    <color name="green">#4CAF50</color>
    <color name="blue">#2196F3</color>
    
    <color name="background">#FAFAFA</color>
</resources>
```

#### 6.2 Update strings.xml

1. Open **res → values → strings.xml**
2. Add these strings:

```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">Student Task Manager</string>
    
    <string name="title_main">My Tasks</string>
    <string name="title_add_task">Add New Task</string>
    <string name="title_edit_task">Edit Task</string>
    
    <string name="button_save">Save Task</string>
    <string name="button_update">Update Task</string>
    
    <string name="hint_title">Task Title</string>
    <string name="hint_description">Task Description</string>
    
    <string name="helper_required">Required</string>
    
    <string name="error_title_empty">Title is required</string>
    <string name="error_description_empty">Description is required</string>
    
    <string name="success_task_added">Task added successfully!</string>
    <string name="success_task_updated">Task updated successfully!</string>
    <string name="success_task_deleted">Task deleted successfully</string>
    
    <string name="empty_tasks">No tasks yet!\n\nTap + to add your first task</string>
    
    <string name="dialog_delete_title">Delete Task</string>
    <string name="dialog_delete_message">Are you sure you want to delete this task?</string>
</resources>
```

#### 6.3 Update themes.xml

1. Open **res → values → themes.xml**
2. Ensure you have NoActionBar style:

```xml
<resources xmlns:tools="http://schemas.android.com/tools">
    <style name="Theme.StudentTaskManager" parent="Theme.MaterialComponents.DayNight.DarkActionBar">
        <item name="colorPrimary">@color/colorPrimary</item>
        <item name="colorPrimaryVariant">@color/colorPrimaryDark</item>
        <item name="colorOnPrimary">@color/white</item>
        <item name="colorSecondary">@color/colorAccent</item>
        <item name="android:statusBarColor">@color/colorPrimaryDark</item>
    </style>
    
    <style name="Theme.StudentTaskManager.NoActionBar">
        <item name="windowActionBar">false</item>
        <item name="windowNoTitle">true</item>
    </style>
</resources>
```

---

### STEP 7: Update AndroidManifest.xml (5 minutes)

1. Open **manifests → AndroidManifest.xml**
2. Update the `<application>` section:

```xml
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.example.studenttaskmanager">

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.StudentTaskManager">
        
        <!-- Splash Activity (LAUNCHER) -->
        <activity
            android:name=".SplashActivity"
            android:theme="@style/Theme.StudentTaskManager.NoActionBar"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
        
        <!-- Main Activity -->
        <activity
            android:name=".MainActivity"
            android:theme="@style/Theme.StudentTaskManager.NoActionBar"
            android:windowSoftInputMode="adjustResize" />
        
        <!-- Add Task Activity -->
        <activity
            android:name=".AddTaskActivity"
            android:theme="@style/Theme.StudentTaskManager.NoActionBar"
            android:windowSoftInputMode="adjustResize"
            android:parentActivityName=".MainActivity" />
        
        <!-- Update Task Activity -->
        <activity
            android:name=".UpdateTaskActivity"
            android:theme="@style/Theme.StudentTaskManager.NoActionBar"
            android:windowSoftInputMode="adjustResize"
            android:parentActivityName=".MainActivity" />
    
    </application>

</manifest>
```

**⚠️ IMPORTANT:** Make sure SplashActivity has the `<intent-filter>` (LAUNCHER), not MainActivity!

---

### STEP 8: Fix Import Errors (5 minutes)

After pasting all code, you'll see red underlines for imports.

**Quick Fix:**
1. Place cursor on red text
2. Press **Alt + Enter** (Windows/Linux) or **Option + Return** (Mac)
3. Select **"Import class"**
4. Repeat for all imports

**OR** use Auto-Import:
- **File → Settings → Editor → General → Auto Import**
- Check **"Add unambiguous imports on the fly"**

---

### STEP 9: Build and Run (3 minutes)

#### 9.1 Create Virtual Device (First time only)

1. Click **AVD Manager** (phone icon) in toolbar
2. Click **Create Virtual Device**
3. Select **Pixel 5** or any phone
4. Select System Image: **API 33 (Android 13)** or latest
5. Click **Next → Finish**

#### 9.2 Run the App

1. Click **Run** button (green play icon)
2. Select your virtual device or connected physical device
3. Wait for build to complete
4. App should launch automatically!

---

## 🧪 TESTING YOUR APP

### Test Checklist:

1. ✅ **Splash Screen**
   - App shows splash for 2 seconds
   - Automatically navigates to task list

2. ✅ **Empty State**
   - Shows "No tasks yet" message
   - FAB button visible

3. ✅ **Add Task**
   - Click FAB (+)
   - Enter title and description
   - Click "Save Task"
   - Should return to main screen
   - Task should appear in list

4. ✅ **View Tasks**
   - Task shows in RecyclerView
   - Card displays title and description
   - Edit and delete buttons visible

5. ✅ **Edit Task**
   - Click edit button (pencil icon)
   - Form pre-filled with existing data
   - Modify title/description
   - Click "Update Task"
   - Changes reflected in list

6. ✅ **Delete Task**
   - Click delete button (trash icon)
   - Confirmation dialog appears
   - Click "Delete"
   - Task removed from list
   - Success toast message shown

7. ✅ **Input Validation**
   - Try saving empty title → Error shown
   - Try saving empty description → Error shown
   - Error messages displayed inline

8. ✅ **Data Persistence**
   - Add some tasks
   - Close app completely
   - Reopen app
   - Tasks should still be there (SQLite working)

---

## 🐛 COMMON ISSUES AND SOLUTIONS

### Issue 1: Build Fails - "Cannot resolve symbol R"
**Solution:** 
- Click **Build → Clean Project**
- Then **Build → Rebuild Project**
- Wait for Gradle to sync

### Issue 2: App Crashes on Launch
**Solution:**
- Check Logcat (bottom panel in Android Studio)
- Look for red error messages
- Common causes:
  - Missing activity declaration in AndroidManifest.xml
  - Wrong package name in Java files
  - Missing layout files

### Issue 3: Layout Not Showing Correctly
**Solution:**
- Open XML file
- Click **Design** tab
- Check for errors in **Component Tree**
- Verify all IDs match between XML and Java

### Issue 4: Database Not Working
**Solution:**
- Uninstall app from device/emulator
- Reinstall (this clears database)
- Check DBHelper onCreate() method

### Issue 5: RecyclerView Not Displaying Items
**Solution:**
- Verify LayoutManager is set in MainActivity
- Check adapter is attached to RecyclerView
- Ensure taskList is populated from database
- Check Logcat for errors

---

## 📸 TAKING SCREENSHOTS FOR RESUME

1. Run app on emulator
2. Navigate through all screens
3. Use **Screenshot** button in emulator toolbar
4. Or press **Ctrl + S** (Windows) / **Cmd + S** (Mac)
5. Screenshots saved to: **Pictures → Screenshots** folder

**Recommended Screenshots:**
1. Splash screen
2. Empty task list
3. Task list with 3-4 tasks
4. Add task screen
5. Edit task screen

---

## 📦 GENERATING APK FILE

### For Testing/Demo:

1. Click **Build → Build Bundle(s) / APK(s) → Build APK(s)**
2. Wait for build to complete
3. Click **"locate"** in notification
4. APK location: **app/build/outputs/apk/debug/app-debug.apk**
5. Share this APK for testing

### For Release (Optional):

1. Click **Build → Generate Signed Bundle / APK**
2. Select **APK**
3. Create new keystore (first time)
4. Fill in keystore details
5. Select **release** build variant
6. Click **Finish**
7. Signed APK ready for distribution

---

## 📝 README.md FOR YOUR PROJECT

Create a **README.md** file in your project root:

```markdown
# Student Task Manager - Android App

A simple and intuitive task management application for students, built with Java and SQLite.

## Features

- ✅ Add new tasks with title and description
- ✅ View all tasks in a scrollable list
- ✅ Edit existing tasks
- ✅ Delete tasks with confirmation
- ✅ Data persistence using SQLite
- ✅ Material Design UI
- ✅ Input validation

## Technology Stack

- **Language:** Java
- **UI:** XML Layouts
- **Database:** SQLite
- **Design:** Material Design Components
- **Architecture:** RecyclerView with ViewHolder pattern

## Screenshots

[Add your screenshots here]

## Installation

1. Clone this repository
2. Open in Android Studio
3. Build and run on emulator or physical device

## Requirements

- Android Studio
- Minimum SDK: API 21 (Android 5.0)
- Target SDK: API 33 (Android 13)

## Key Concepts Demonstrated

- Activity Lifecycle Management
- SQLite Database Operations (CRUD)
- RecyclerView with Custom Adapter
- Material Design Implementation
- Intent-based Navigation
- Input Validation
- AlertDialog for confirmations

## Author

[Your Name]

## License

This project is open source and available for educational purposes.
```

---

## 🎯 NEXT STEPS AFTER COMPLETION

1. **Test Thoroughly** - Go through entire test checklist
2. **Take Screenshots** - For portfolio/resume
3. **Generate APK** - For demo purposes
4. **Upload to GitHub** - Version control and showcase
5. **Write Documentation** - README, comments in code
6. **Add to Resume** - List technologies and features

---

## 📚 ADDITIONAL RESOURCES

### Official Android Documentation:
- https://developer.android.com/guide
- https://developer.android.com/training/data-storage/sqlite
- https://developer.android.com/guide/topics/ui/layout/recyclerview

### Material Design Guidelines:
- https://material.io/design

### YouTube Tutorials (for reference):
- "Android SQLite Database Tutorial"
- "RecyclerView Android Tutorial"
- "Material Design Android"

---

## 💡 TIPS FOR SUCCESS

1. **Follow Order** - Complete steps sequentially
2. **Test Frequently** - Run app after each major step
3. **Read Errors Carefully** - Logcat provides useful information
4. **Use Autocomplete** - Android Studio suggests code completions
5. **Ask for Help** - Stack Overflow for specific errors
6. **Comment Your Code** - Helps in interviews and understanding
7. **Keep It Simple** - Don't overcomplicate for first project

---

## ✅ PROJECT COMPLETION CHECKLIST

Before considering your project complete:

- [ ] All 7 Java files created and working
- [ ] All 5 XML layouts designed
- [ ] All drawable resources added
- [ ] AndroidManifest.xml updated correctly
- [ ] App runs without crashes
- [ ] All CRUD operations working
- [ ] Input validation functioning
- [ ] Data persists after app restart
- [ ] Screenshots captured
- [ ] APK generated
- [ ] README.md written
- [ ] Code commented
- [ ] Prepared for interview questions

---

## 🎉 CONGRATULATIONS!

Once all steps are complete, you have successfully built a professional Android app using Java, SQLite, and Material Design. This project demonstrates essential Android development skills and is perfect for your resume!

**Time to Build:** 4-6 hours for beginners

**Resume Impact:** ⭐⭐⭐⭐☆

---

**Good luck with your Android development journey!** 🚀
