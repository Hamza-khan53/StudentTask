// MainActivity.java - Main screen displaying task list
// Package: com.example.studenttaskmanager

package com.example.studenttaskmanager;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;

/**
 * Main Activity - Displays list of all tasks
 * Handles view, edit, and delete operations
 */
public class MainActivity extends AppCompatActivity implements TaskAdapter.OnTaskClickListener {
    
    // UI Components
    private RecyclerView recyclerView;
    private FloatingActionButton fabAdd;
    private TextView textViewEmpty;
    private Toolbar toolbar;
    
    // Data
    private TaskAdapter adapter;
    private ArrayList<TaskModel> taskList;
    private DBHelper dbHelper;
    
    /**
     * Called when activity is first created
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        // Initialize database helper
        dbHelper = new DBHelper(this);
        
        // Initialize task list
        taskList = new ArrayList<>();
        
        // Initialize UI components
        initializeViews();
        
        // Setup toolbar
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("My Tasks");
        
        // Setup RecyclerView
        setupRecyclerView();
        
        // Load tasks from database
        loadTasksFromDatabase();
        
        // Setup FAB click listener
        fabAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to AddTaskActivity
                Intent intent = new Intent(MainActivity.this, AddTaskActivity.class);
                startActivity(intent);
            }
        });
    }
    
    /**
     * Initialize all views
     */
    private void initializeViews() {
        recyclerView = findViewById(R.id.recyclerViewTasks);
        fabAdd = findViewById(R.id.fabAdd);
        textViewEmpty = findViewById(R.id.textViewEmpty);
        toolbar = findViewById(R.id.toolbar);
    }
    
    /**
     * Setup RecyclerView with adapter and layout manager
     */
    private void setupRecyclerView() {
        // Set layout manager - Linear (vertical list)
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        
        // Create and set adapter
        adapter = new TaskAdapter(this, taskList, this);
        recyclerView.setAdapter(adapter);
        
        // Optional: Improve performance
        recyclerView.setHasFixedSize(true);
    }
    
    /**
     * Load all tasks from SQLite database
     */
    private void loadTasksFromDatabase() {
        // Clear existing list
        taskList.clear();
        
        // Get cursor with all tasks
        Cursor cursor = dbHelper.getAllTasks();
        
        // Check if cursor has data
        if (cursor != null && cursor.getCount() > 0) {
            // Hide empty state message
            textViewEmpty.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
            
            // Loop through cursor and add tasks to list
            while (cursor.moveToNext()) {
                int id = cursor.getInt(cursor.getColumnIndex("id"));
                String title = cursor.getString(cursor.getColumnIndex("title"));
                String description = cursor.getString(cursor.getColumnIndex("description"));
                String createdAt = cursor.getString(cursor.getColumnIndex("created_at"));
                
                // Create TaskModel object
                TaskModel task = new TaskModel(id, title, description, createdAt);
                taskList.add(task);
            }
            
            // Close cursor to prevent memory leak
            cursor.close();
            
            // Notify adapter that data has changed
            adapter.notifyDataSetChanged();
        } else {
            // Show empty state message
            textViewEmpty.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        }
    }
    
    /**
     * Called when activity resumes
     * Perfect for refreshing data
     */
    @Override
    protected void onResume() {
        super.onResume();
        // Reload tasks (in case new task was added or updated)
        loadTasksFromDatabase();
    }
    
    /**
     * Handle edit button click (from TaskAdapter interface)
     */
    @Override
    public void onEditClick(TaskModel task, int position) {
        // Create intent to navigate to UpdateTaskActivity
        Intent intent = new Intent(MainActivity.this, UpdateTaskActivity.class);
        
        // Pass task data via intent extras
        intent.putExtra("task_id", task.getId());
        intent.putExtra("task_title", task.getTitle());
        intent.putExtra("task_description", task.getDescription());
        
        // Start activity
        startActivity(intent);
    }
    
    /**
     * Handle delete button click (from TaskAdapter interface)
     */
    @Override
    public void onDeleteClick(TaskModel task, int position) {
        // Show confirmation dialog
        showDeleteConfirmationDialog(task, position);
    }
    
    /**
     * Show AlertDialog to confirm task deletion
     */
    private void showDeleteConfirmationDialog(TaskModel task, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete Task");
        builder.setMessage("Are you sure you want to delete this task?");
        
        // Positive button - Delete
        builder.setPositiveButton("Delete", (dialog, which) -> {
            // Delete from database
            boolean isDeleted = dbHelper.deleteTask(task.getId());
            
            if (isDeleted) {
                // Remove from list and notify adapter
                taskList.remove(position);
                adapter.notifyItemRemoved(position);
                
                // Show success message
                Toast.makeText(MainActivity.this, 
                              "Task deleted successfully", 
                              Toast.LENGTH_SHORT).show();
                
                // Check if list is empty
                if (taskList.isEmpty()) {
                    textViewEmpty.setVisibility(View.VISIBLE);
                    recyclerView.setVisibility(View.GONE);
                }
            } else {
                // Show error message
                Toast.makeText(MainActivity.this, 
                              "Failed to delete task", 
                              Toast.LENGTH_SHORT).show();
            }
        });
        
        // Negative button - Cancel
        builder.setNegativeButton("Cancel", (dialog, which) -> {
            dialog.dismiss();
        });
        
        // Show dialog
        builder.create().show();
    }
    
    /**
     * Called when activity is destroyed
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Close database connection (optional, SQLiteOpenHelper manages this)
        if (dbHelper != null) {
            dbHelper.close();
        }
    }
}

/**
 * INTERVIEW POINTS:
 * 
 * 1. ACTIVITY LIFECYCLE:
 *    - onCreate(): Initialize views, setup RecyclerView, load data
 *    - onResume(): Refresh data (called when returning from other activities)
 *    - onDestroy(): Clean up resources
 * 
 * 2. WHY onResume() FOR DATA REFRESH?
 *    - Called every time activity becomes visible
 *    - User adds/edits task → returns to MainActivity → onResume() called
 *    - Ensures UI always shows latest data
 *    - Alternative: Use startActivityForResult() with result codes
 * 
 * 3. INTENT AND DATA PASSING:
 *    - Used to navigate between activities
 *    - putExtra() to send data (key-value pairs)
 *    - Supports primitives, Strings, Parcelable, Serializable
 * 
 * 4. CURSOR HANDLING:
 *    - moveToNext() returns false when no more rows
 *    - getColumnIndex() gets column position by name
 *    - Always close cursor to prevent memory leaks
 * 
 * 5. FLOATINGACTIONBUTTON (FAB):
 *    - Material Design component for primary action
 *    - Positioned in bottom-right corner
 *    - Used for "Add" action (most common use case)
 * 
 * 6. EMPTY STATE HANDLING:
 *    - Show friendly message when no data
 *    - Better UX than showing blank screen
 *    - Toggle visibility between RecyclerView and empty message
 * 
 * 7. ALERTDIALOG:
 *    - Confirmation dialog before destructive actions (delete)
 *    - Prevents accidental deletions
 *    - Good UX practice
 * 
 * 8. TOAST MESSAGES:
 *    - Brief messages for user feedback
 *    - LENGTH_SHORT (2 seconds) or LENGTH_LONG (3.5 seconds)
 *    - Non-intrusive notifications
 * 
 * 9. INTERFACE IMPLEMENTATION:
 *    - Implements OnTaskClickListener interface
 *    - Handles click events from adapter
 *    - Separation of concerns
 * 
 * WHY THIS DESIGN?
 * - Single Responsibility: Each method has one purpose
 * - Lifecycle aware: Uses appropriate lifecycle methods
 * - User-friendly: Confirmations, feedback messages, empty states
 * - Maintainable: Clean code structure, well-commented
 * 
 * POTENTIAL IMPROVEMENTS:
 * - Add search functionality
 * - Implement sorting options (by date, title)
 * - Add swipe-to-refresh
 * - Show task creation date in list
 * - Add task completion checkbox
 * - Implement undo for delete action (Snackbar with action)
 */
