// TaskModel.java - POJO (Plain Old Java Object) for Task Entity
// Package: com.example.studenttaskmanager

package com.example.studenttaskmanager;

/**
 * Model class representing a Task entity
 * This class follows the JavaBean convention with private fields
 * and public getter/setter methods (Encapsulation)
 */
public class TaskModel {
    
    // Private fields - Encapsulation
    private int id;
    private String title;
    private String description;
    private String createdAt;
    
    // Empty Constructor - Required for object creation
    public TaskModel() {
    }
    
    // Parameterized Constructor - For creating objects with initial values
    public TaskModel(int id, String title, String description, String createdAt) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.createdAt = createdAt;
    }
    
    // Constructor without createdAt (for adding new tasks)
    public TaskModel(String title, String description) {
        this.title = title;
        this.description = description;
    }
    
    // Getter and Setter methods
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public String getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }
    
    // toString() method - For debugging and logging
    @Override
    public String toString() {
        return "TaskModel{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", createdAt='" + createdAt + '\'' +
                '}';
    }
}

/**
 * INTERVIEW POINTS:
 * 
 * 1. ENCAPSULATION: Private fields with public getter/setter methods
 *    - Protects data integrity
 *    - Allows controlled access to object properties
 * 
 * 2. CONSTRUCTOR OVERLOADING: Multiple constructors for flexibility
 *    - Empty constructor for creating blank objects
 *    - Parameterized constructor for initializing with values
 * 
 * 3. JAVABEANS CONVENTION: Standard naming (get/set prefix)
 *    - Makes the class compatible with Android frameworks
 *    - Follows industry best practices
 * 
 * 4. toString() METHOD: Overridden for debugging
 *    - Helps in logging and debugging
 *    - Provides readable string representation of object
 * 
 * WHY THIS DESIGN?
 * - Separates data from business logic (Single Responsibility Principle)
 * - Easy to pass between activities using Intent (Parcelable/Serializable)
 * - Can be easily converted to JSON for API calls
 * - Reusable across different parts of the application
 */
