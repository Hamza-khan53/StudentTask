# Student Task Manager – Android (Java)

> **Attribution:** this is a fork of *Student Task Manager (Android, Java)* by its
> original author (add the upstream link here). Check the upstream repository for
> its license terms before redistributing.
>
> **This fork adds a UI redesign**: new colour palette, Poppins font, gradient
> headers, redesigned cards, empty state, splash, and dark mode. See
> [`ui-redesign/`](ui-redesign/README.md) for details and install steps.


This repository contains the complete project structure, UI layouts, and application logic design for a **native Android Task Manager application**.  
The project is intended for **Android Developer (Java) resume and interview preparation**.

---

## 📱 Project Overview

**Student Task Manager** is a native Android application that helps users manage daily tasks efficiently.  
It supports adding, updating, viewing, and deleting tasks using a local SQLite database and follows Android best practices.

---

## ✨ Features

- Add new tasks
- View task list
- Update existing tasks
- Delete tasks
- Local data storage using SQLite
- Clean UI based on Material Design
- RecyclerView for task listing

---

## 🛠️ Tech Stack

- **Language:** Java  
- **IDE:** Android Studio  
- **UI:** XML (Material Design)  
- **Database:** SQLite  
- **Architecture:** Activities + Adapter pattern  

---

## 🧱 App Structure

- `MainActivity` – Displays list of tasks
- `AddTaskActivity` – Add new task
- `UpdateTaskActivity` – Edit existing task
- `DBHelper` – SQLite database operations
- `RecyclerView Adapter` – Task list binding
- XML layout files for each screen

---

## 🧠 Development Notes

- This repository includes **Android-native project guidance and pseudocode**
- UI layouts and database schema are fully defined
- The project is designed to be **implemented in Android Studio using Java**
- App architecture and logic were prepared with AI assistance

---

## 🚀 How to Run (Android Studio)

1. Create a new Android project in Android Studio (Java)
2. Copy Java logic and XML layouts from this repository
3. Configure SQLite database using DBHelper
4. Run the app on emulator or physical device

---

## 📌 Resume Description (Use This)

> Developed a native Android application using Java, XML, and SQLite.  
> Designed task management features with CRUD operations and Material Design UI.  
> Application architecture and logic prepared with AI assistance and hosted on GitHub.

---

## 👤 Author

**Nikhil Rajput**  
- GitHub: https://github.com/NikhilRajput23  
- Role: Android Developer (Fresher)

---

## 📄 License

This project is for educational and resume purposes.
