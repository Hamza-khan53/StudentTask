// TaskAdapter.java - RecyclerView Adapter for Task List
// Package: com.example.studenttaskmanager

package com.example.studenttaskmanager;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

/**
 * Adapter class for RecyclerView to display list of tasks
 * Follows the ViewHolder pattern for efficient view recycling
 */
public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskViewHolder> {
    
    private Context context;
    private ArrayList<TaskModel> taskList;
    private OnTaskClickListener listener;
    
    // Interface for handling click events
    public interface OnTaskClickListener {
        void onEditClick(TaskModel task, int position);
        void onDeleteClick(TaskModel task, int position);
    }
    
    // Constructor
    public TaskAdapter(Context context, ArrayList<TaskModel> taskList, 
                       OnTaskClickListener listener) {
        this.context = context;
        this.taskList = taskList;
        this.listener = listener;
    }
    
    /**
     * Called when RecyclerView needs a new ViewHolder
     * Inflates the item layout and creates ViewHolder
     */
    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the task_item.xml layout
        View view = LayoutInflater.from(context)
                .inflate(R.layout.task_item, parent, false);
        
        return new TaskViewHolder(view);
    }
    
    /**
     * Called to display data at specified position
     * Binds data to ViewHolder views
     */
    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        // Get task at current position
        TaskModel task = taskList.get(position);
        
        // Set data to views
        holder.titleTextView.setText(task.getTitle());
        holder.descriptionTextView.setText(task.getDescription());
        
        // Set click listener for edit button
        holder.editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    listener.onEditClick(task, holder.getAdapterPosition());
                }
            }
        });
        
        // Set click listener for delete button
        holder.deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    listener.onDeleteClick(task, holder.getAdapterPosition());
                }
            }
        });
    }
    
    /**
     * Returns the total number of items in the list
     */
    @Override
    public int getItemCount() {
        return taskList.size();
    }
    
    /**
     * ViewHolder class - Holds references to item views
     * Improves performance by caching view references
     */
    public static class TaskViewHolder extends RecyclerView.ViewHolder {
        
        TextView titleTextView;
        TextView descriptionTextView;
        ImageButton editButton;
        ImageButton deleteButton;
        
        public TaskViewHolder(@NonNull View itemView) {
            super(itemView);
            
            // Initialize views using findViewById
            titleTextView = itemView.findViewById(R.id.textViewTitle);
            descriptionTextView = itemView.findViewById(R.id.textViewDescription);
            editButton = itemView.findViewById(R.id.buttonEdit);
            deleteButton = itemView.findViewById(R.id.buttonDelete);
        }
    }
    
    /**
     * Update the entire task list and refresh
     */
    public void updateTaskList(ArrayList<TaskModel> newList) {
        this.taskList = newList;
        notifyDataSetChanged(); // Refresh entire list
    }
    
    /**
     * Remove item at specific position
     */
    public void removeTask(int position) {
        taskList.remove(position);
        notifyItemRemoved(position); // Animate removal
    }
    
    /**
     * Add new task to the list
     */
    public void addTask(TaskModel task) {
        taskList.add(0, task); // Add at top
        notifyItemInserted(0); // Animate insertion
    }
}

/**
 * INTERVIEW POINTS:
 * 
 * 1. RECYCLERVIEW ADAPTER:
 *    - Manages a large dataset efficiently
 *    - Only creates views for visible items + few extras
 *    - Recycles views as user scrolls
 * 
 * 2. VIEWHOLDER PATTERN:
 *    - Caches view references to avoid repeated findViewById calls
 *    - Significantly improves scrolling performance
 *    - Required by RecyclerView (unlike ListView where it was optional)
 * 
 * 3. THREE KEY METHODS:
 *    - onCreateViewHolder(): Creates new ViewHolder (called rarely)
 *    - onBindViewHolder(): Binds data to existing ViewHolder (called frequently)
 *    - getItemCount(): Returns total items in dataset
 * 
 * 4. INTERFACE FOR CLICK HANDLING:
 *    - Separation of concerns - Adapter doesn't handle business logic
 *    - Activity/Fragment implements interface and handles actions
 *    - Clean architecture pattern
 * 
 * 5. NOTIFY METHODS:
 *    - notifyDataSetChanged() - Refresh entire list (use sparingly)
 *    - notifyItemRemoved() - Animate single item removal
 *    - notifyItemInserted() - Animate single item insertion
 *    - Improves user experience with smooth animations
 * 
 * 6. getAdapterPosition():
 *    - Used instead of 'position' parameter in click listeners
 *    - Prevents issues with position changes during async operations
 *    - Best practice for RecyclerView
 * 
 * WHY RECYCLERVIEW OVER LISTVIEW?
 * - Enforces ViewHolder pattern (ListView doesn't)
 * - Better performance with large datasets
 * - More flexible (supports Grid, Staggered layouts)
 * - Built-in item animations
 * - Recommended by Google for modern Android apps
 * 
 * PERFORMANCE TIPS:
 * - Use DiffUtil for large dataset updates (calculates minimal changes)
 * - Avoid complex operations in onBindViewHolder
 * - Use stable IDs with setHasStableIds()
 * - Consider using ListAdapter for automatic diffing
 * 
 * POTENTIAL IMPROVEMENTS:
 * - Implement item click listener (for viewing task details)
 * - Add swipe-to-delete gesture
 * - Implement drag-and-drop reordering
 * - Add item animations
 * - Use DiffUtil instead of notifyDataSetChanged
 */
