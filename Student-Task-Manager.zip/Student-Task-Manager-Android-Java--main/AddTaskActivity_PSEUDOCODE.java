// AddTaskActivity.java - Add new task screen
// Package: com.example.studenttaskmanager

package com.example.studenttaskmanager;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

/**
 * AddTaskActivity - Screen for adding new tasks
 * Includes input validation and database insertion
 */
public class AddTaskActivity extends AppCompatActivity {
    
    // UI Components
    private TextInputLayout titleInputLayout;
    private TextInputLayout descriptionInputLayout;
    private TextInputEditText titleEditText;
    private TextInputEditText descriptionEditText;
    private Button buttonSave;
    private Toolbar toolbar;
    
    // Database helper
    private DBHelper dbHelper;
    
    /**
     * Called when activity is created
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);
        
        // Initialize database helper
        dbHelper = new DBHelper(this);
        
        // Initialize views
        initializeViews();
        
        // Setup toolbar with back button
        setupToolbar();
        
        // Setup save button click listener
        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveTask();
            }
        });
    }
    
    /**
     * Initialize all views
     */
    private void initializeViews() {
        toolbar = findViewById(R.id.toolbar);
        titleInputLayout = findViewById(R.id.titleInputLayout);
        descriptionInputLayout = findViewById(R.id.descriptionInputLayout);
        titleEditText = findViewById(R.id.editTextTitle);
        descriptionEditText = findViewById(R.id.editTextDescription);
        buttonSave = findViewById(R.id.buttonSave);
    }
    
    /**
     * Setup toolbar with back navigation
     */
    private void setupToolbar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Add New Task");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true); // Show back button
    }
    
    /**
     * Handle back button click in toolbar
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            // Back button clicked
            finish(); // Close this activity
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    
    /**
     * Validate input and save task to database
     */
    private void saveTask() {
        // Get input values
        String title = titleEditText.getText().toString().trim();
        String description = descriptionEditText.getText().toString().trim();
        
        // Reset previous errors
        titleInputLayout.setError(null);
        descriptionInputLayout.setError(null);
        
        // Validate title
        if (title.isEmpty()) {
            titleInputLayout.setError("Title is required");
            titleEditText.requestFocus();
            return;
        }
        
        if (title.length() < 3) {
            titleInputLayout.setError("Title must be at least 3 characters");
            titleEditText.requestFocus();
            return;
        }
        
        // Validate description
        if (description.isEmpty()) {
            descriptionInputLayout.setError("Description is required");
            descriptionEditText.requestFocus();
            return;
        }
        
        if (description.length() < 5) {
            descriptionInputLayout.setError("Description must be at least 5 characters");
            descriptionEditText.requestFocus();
            return;
        }
        
        // All validations passed - save to database
        boolean isInserted = dbHelper.addTask(title, description);
        
        if (isInserted) {
            // Show success message
            Toast.makeText(this, "Task added successfully!", Toast.LENGTH_SHORT).show();
            
            // Close activity and return to MainActivity
            finish();
        } else {
            // Show error message
            Toast.makeText(this, "Failed to add task. Please try again.", 
                          Toast.LENGTH_SHORT).show();
        }
    }
    
    /**
     * Handle device back button
     */
    @Override
    public void onBackPressed() {
        // Optional: Show confirmation dialog if user has entered data
        String title = titleEditText.getText().toString().trim();
        String description = descriptionEditText.getText().toString().trim();
        
        if (!title.isEmpty() || !description.isEmpty()) {
            // Show confirmation dialog (optional)
            // For simplicity, just close the activity
            super.onBackPressed();
        } else {
            super.onBackPressed();
        }
    }
}

/**
 * INTERVIEW POINTS:
 * 
 * 1. TEXTINPUTLAYOUT (Material Design):
 *    - Wrapper for EditText with floating label
 *    - Built-in error display with setError()
 *    - Provides Material Design animations
 *    - Better UX than plain EditText
 * 
 * 2. INPUT VALIDATION:
 *    - Client-side validation before database operation
 *    - Check for empty fields
 *    - Minimum length validation
 *    - Immediate user feedback with error messages
 *    - requestFocus() moves cursor to error field
 * 
 * 3. TOOLBAR WITH BACK BUTTON:
 *    - setDisplayHomeAsUpEnabled(true) shows back arrow
 *    - onOptionsItemSelected() handles back button click
 *    - android.R.id.home is the back button's ID
 *    - Consistent navigation across app
 * 
 * 4. trim() METHOD:
 *    - Removes leading and trailing whitespace
 *    - Prevents "   " (spaces only) from passing validation
 *    - Good practice for string input
 * 
 * 5. finish() METHOD:
 *    - Closes current activity
 *    - Returns to previous activity (MainActivity)
 *    - Removes activity from back stack
 * 
 * 6. TOAST FOR FEEDBACK:
 *    - Simple, non-intrusive user notification
 *    - Success/failure messages
 *    - Better UX than silent operations
 * 
 * 7. ERROR HANDLING:
 *    - Check boolean return value from database operation
 *    - Provide appropriate feedback to user
 *    - Don't assume operations always succeed
 * 
 * WHY THIS DESIGN?
 * - Clear separation: validation → database → feedback
 * - User-friendly: Inline errors, focus management
 * - Material Design: Modern, consistent UI
 * - Error prevention: Validation before database operation
 * 
 * VALIDATION BEST PRACTICES:
 * - Empty check (required fields)
 * - Length validation (minimum/maximum)
 * - Format validation (email, phone, etc.)
 * - Special character validation (if needed)
 * - Real-time validation (TextWatcher for live feedback)
 * 
 * POTENTIAL IMPROVEMENTS:
 * - Add TextWatcher for real-time validation
 * - Implement character counter (TextInputLayout supports this)
 * - Add category/priority selection
 * - Implement date/time picker for deadline
 * - Save draft on back press
 * - Add "Cancel" button alongside "Save"
 * - Disable save button while saving (prevent double-click)
 */
