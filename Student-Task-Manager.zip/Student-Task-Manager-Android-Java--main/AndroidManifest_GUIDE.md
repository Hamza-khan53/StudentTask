# AndroidManifest.xml - Application Configuration
# Location: app/src/main/AndroidManifest.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.example.studenttaskmanager">

    <!-- Permissions (if needed) -->
    <!-- <uses-permission android:name="android.permission.INTERNET" /> -->

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.StudentTaskManager">
        
        <!-- Splash Activity (LAUNCHER - App starts here) -->
        <activity
            android:name=".SplashActivity"
            android:theme="@style/Theme.StudentTaskManager.NoActionBar"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
        
        <!-- Main Activity -->
        <activity
            android:name=".MainActivity"
            android:theme="@style/Theme.StudentTaskManager.NoActionBar"
            android:windowSoftInputMode="adjustResize" />
        
        <!-- Add Task Activity -->
        <activity
            android:name=".AddTaskActivity"
            android:theme="@style/Theme.StudentTaskManager.NoActionBar"
            android:windowSoftInputMode="adjustResize"
            android:parentActivityName=".MainActivity" />
        
        <!-- Update Task Activity -->
        <activity
            android:name=".UpdateTaskActivity"
            android:theme="@style/Theme.StudentTaskManager.NoActionBar"
            android:windowSoftInputMode="adjustResize"
            android:parentActivityName=".MainActivity" />
    
    </application>

</manifest>
```

## KEY CONCEPTS:

### 1. Package Declaration
```xml
package="com.example.studenttaskmanager"
```
- Unique identifier for your app
- Convention: com.yourname.appname
- Must match package in Java files

### 2. Application-Level Attributes
- **android:allowBackup**: Allows app data backup to Google Drive
- **android:icon**: App icon (launcher icon)
- **android:label**: App name shown to users
- **android:supportsRtl**: Support Right-to-Left languages (Arabic, Hebrew)
- **android:theme**: App-wide theme

### 3. Activity Declaration
All activities MUST be declared in manifest, or app will crash

### 4. Intent Filter (Launcher Activity)
```xml
<intent-filter>
    <action android:name="android.intent.action.MAIN" />
    <category android:name="android.intent.category.LAUNCHER" />
</intent-filter>
```
- Marks SplashActivity as the entry point
- App launches this activity first
- Shows icon in app drawer
- ONLY ONE activity should have this filter

### 5. android:exported="true"
- Required for Android 12+ (API 31+) for activities with intent-filters
- Indicates activity can be launched by other apps
- Security requirement

### 6. android:windowSoftInputMode="adjustResize"
- Handles keyboard behavior
- "adjustResize": Layout resizes when keyboard appears
- "adjustPan": Layout pans/scrolls (alternative)
- Critical for activities with input fields

### 7. android:parentActivityName
```xml
android:parentActivityName=".MainActivity"
```
- Defines parent activity for up navigation
- Enables back arrow in toolbar
- Proper navigation hierarchy

### 8. Theme Variations
- **Theme.StudentTaskManager**: Default theme
- **Theme.StudentTaskManager.NoActionBar**: No default ActionBar (we use Toolbar)

### 9. Permissions
Uncomment if needed:
```xml
<uses-permission android:name="android.permission.INTERNET" />
```
- Required for network operations
- Not needed for this offline app

## INTERVIEW POINTS:

**Q: Why declare activities in manifest?**
A: Android system needs to know all app components before launching. Undeclared activities will crash with ActivityNotFoundException.

**Q: What is intent-filter?**
A: Declares what intents an activity can respond to. MAIN + LAUNCHER makes it the app entry point.

**Q: Explain windowSoftInputMode.**
A: Controls how keyboard affects layout. adjustResize resizes layout to fit remaining space. adjustPan scrolls content without resizing.

**Q: Why NoActionBar theme?**
A: We use custom Toolbar instead of default ActionBar for more flexibility and Material Design compliance.

**Q: What is parentActivityName?**
A: Defines navigation hierarchy. Enables "up" navigation (back arrow in toolbar) to parent activity.

## ADDITIONAL MANIFEST ELEMENTS (for enhancement):

```xml
<!-- Support different screen sizes -->
<supports-screens
    android:smallScreens="true"
    android:normalScreens="true"
    android:largeScreens="true"
    android:xlargeScreens="true" />

<!-- Minimum SDK version -->
<uses-sdk
    android:minSdkVersion="21"
    android:targetSdkVersion="33" />
```

## COMMON MISTAKES:

1. **Forgetting to declare activity** → ActivityNotFoundException crash
2. **Multiple LAUNCHER activities** → Multiple app icons in drawer
3. **Missing android:exported for API 31+** → App won't install
4. **Wrong package name** → ClassNotFoundException
5. **Not setting windowSoftInputMode** → Bad keyboard UX

## FILE STRUCTURE:
```
app/
├── src/
│   └── main/
│       ├── AndroidManifest.xml  ← This file
│       ├── java/
│       │   └── com/example/studenttaskmanager/
│       │       ├── SplashActivity.java
│       │       ├── MainActivity.java
│       │       ├── AddTaskActivity.java
│       │       ├── UpdateTaskActivity.java
│       │       ├── TaskAdapter.java
│       │       ├── TaskModel.java
│       │       └── DBHelper.java
│       └── res/
│           └── layout/
│               ├── activity_splash.xml
│               ├── activity_main.xml
│               ├── activity_add_task.xml
│               ├── activity_update_task.xml
│               └── task_item.xml
```
