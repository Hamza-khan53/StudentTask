> **Updated:** the colour, theme and style resources in this guide have been
> superseded by the redesigned set in [`ui-redesign/res/`](ui-redesign/README.md).
> Use those files instead of the snippets below.

# colors.xml - Color Resources
# Location: res/values/colors.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <!-- Primary Brand Colors (Material Design) -->
    <color name="colorPrimary">#6200EE</color>
    <color name="colorPrimaryDark">#3700B3</color>
    <color name="colorAccent">#03DAC5</color>
    
    <!-- Basic Colors -->
    <color name="white">#FFFFFF</color>
    <color name="black">#000000</color>
    <color name="grey">#757575</color>
    <color name="light_grey">#E0E0E0</color>
    
    <!-- Status Colors -->
    <color name="red">#F44336</color>
    <color name="green">#4CAF50</color>
    <color name="blue">#2196F3</color>
    
    <!-- Background Colors -->
    <color name="background">#FAFAFA</color>
    <color name="card_background">#FFFFFF</color>
</resources>
```

# strings.xml - String Resources
# Location: res/values/strings.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <!-- App Name -->
    <string name="app_name">Student Task Manager</string>
    
    <!-- Activity Titles -->
    <string name="title_main">My Tasks</string>
    <string name="title_add_task">Add New Task</string>
    <string name="title_edit_task">Edit Task</string>
    
    <!-- Button Labels -->
    <string name="button_save">Save Task</string>
    <string name="button_update">Update Task</string>
    <string name="button_delete">Delete</string>
    <string name="button_cancel">Cancel</string>
    
    <!-- Input Hints -->
    <string name="hint_title">Task Title</string>
    <string name="hint_description">Task Description</string>
    
    <!-- Helper Text -->
    <string name="helper_required">Required</string>
    
    <!-- Error Messages -->
    <string name="error_title_empty">Title is required</string>
    <string name="error_title_short">Title must be at least 3 characters</string>
    <string name="error_description_empty">Description is required</string>
    <string name="error_description_short">Description must be at least 5 characters</string>
    
    <!-- Success Messages -->
    <string name="success_task_added">Task added successfully!</string>
    <string name="success_task_updated">Task updated successfully!</string>
    <string name="success_task_deleted">Task deleted successfully</string>
    
    <!-- Failure Messages -->
    <string name="error_add_failed">Failed to add task. Please try again.</string>
    <string name="error_update_failed">Failed to update task. Please try again.</string>
    <string name="error_delete_failed">Failed to delete task</string>
    
    <!-- Empty State -->
    <string name="empty_tasks">No tasks yet!\n\nTap + to add your first task</string>
    
    <!-- Dialog Messages -->
    <string name="dialog_delete_title">Delete Task</string>
    <string name="dialog_delete_message">Are you sure you want to delete this task?</string>
    
    <!-- Content Descriptions (Accessibility) -->
    <string name="cd_app_logo">App Logo</string>
    <string name="cd_add_task">Add new task</string>
    <string name="cd_edit_task">Edit task</string>
    <string name="cd_delete_task">Delete task</string>
</resources>
```

# themes.xml - App Themes
# Location: res/values/themes.xml

```xml
<resources xmlns:tools="http://schemas.android.com/tools">
    <!-- Base application theme -->
    <style name="Theme.StudentTaskManager" parent="Theme.MaterialComponents.DayNight.DarkActionBar">
        <!-- Primary brand color -->
        <item name="colorPrimary">@color/colorPrimary</item>
        <item name="colorPrimaryVariant">@color/colorPrimaryDark</item>
        <item name="colorOnPrimary">@color/white</item>
        
        <!-- Secondary brand color -->
        <item name="colorSecondary">@color/colorAccent</item>
        <item name="colorSecondaryVariant">@color/colorAccent</item>
        <item name="colorOnSecondary">@color/black</item>
        
        <!-- Status bar color -->
        <item name="android:statusBarColor">@color/colorPrimaryDark</item>
        
        <!-- Background colors -->
        <item name="android:windowBackground">@color/background</item>
    </style>
    
    <!-- Theme with no action bar (for activities using Toolbar) -->
    <style name="Theme.StudentTaskManager.NoActionBar">
        <item name="windowActionBar">false</item>
        <item name="windowNoTitle">true</item>
    </style>
</resources>
```

## WHY USE RESOURCE FILES?

### 1. Separation of Concerns
- Keep UI strings separate from code
- Easier to modify without recompiling
- Designer can work on colors independently

### 2. Localization (Internationalization)
- Easy to create translated versions
- res/values-es/strings.xml for Spanish
- res/values-fr/strings.xml for French
- App automatically uses correct language

### 3. Consistency
- Define color once, use everywhere
- Change in one place updates entire app
- Maintains consistent brand identity

### 4. Theme Support
- Easy to implement dark mode
- res/values-night/colors.xml for dark theme
- System automatically switches themes

### 5. Accessibility
- Content descriptions help screen readers
- Larger text sizes respected
- Better user experience for all

## HOW TO USE IN CODE:

### Colors:
```java
// In Java
int color = ContextCompat.getColor(context, R.color.colorPrimary);
view.setBackgroundColor(color);
```

### Strings:
```java
// In Java
String appName = getString(R.string.app_name);
textView.setText(R.string.success_task_added);
Toast.makeText(this, R.string.error_add_failed, Toast.LENGTH_SHORT).show();
```

### In XML:
```xml
<TextView
    android:text="@string/app_name"
    android:textColor="@color/colorPrimary" />
```

## INTERVIEW POINTS:

**Q: Why use strings.xml instead of hardcoded strings?**
A: Enables localization, easier maintenance, prevents typos, supports accessibility features.

**Q: What is Material Design?**
A: Google's design language for Android. Provides guidelines for colors, typography, spacing, animations.

**Q: How to support multiple languages?**
A: Create values-[language code] folders (e.g., values-es, values-fr) with translated strings.xml.

**Q: What is DayNight theme?**
A: Automatically switches between light and dark themes based on system settings.

## MATERIAL COLOR TOOL:
https://material.io/resources/color/
- Generate color schemes
- Ensures accessibility (contrast ratios)
- Exports ready-to-use color values

## COMMON MISTAKES:

1. **Hardcoding strings** → Can't translate, hard to maintain
2. **Using hex colors in code** → Inconsistent, hard to theme
3. **Not setting content descriptions** → Poor accessibility
4. **Inconsistent naming** → Confusing, hard to find resources
5. **Not using themes** → Duplicate styling code
