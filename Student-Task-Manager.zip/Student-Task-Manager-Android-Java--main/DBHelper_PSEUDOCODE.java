// DBHelper.java - SQLite Database Helper Class
// Package: com.example.studenttaskmanager

package com.example.studenttaskmanager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Database Helper class for managing SQLite database operations
 * Extends SQLiteOpenHelper to handle database creation and version management
 */
public class DBHelper extends SQLiteOpenHelper {
    
    // Database Constants
    private static final String DATABASE_NAME = "TaskDatabase.db";
    private static final int DATABASE_VERSION = 1;
    
    // Table and Column Names
    private static final String TABLE_NAME = "tasks";
    private static final String COL_ID = "id";
    private static final String COL_TITLE = "title";
    private static final String COL_DESCRIPTION = "description";
    private static final String COL_CREATED_AT = "created_at";
    
    // Constructor
    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    
    // Called when database is created for the first time
    @Override
    public void onCreate(SQLiteDatabase db) {
        // SQL CREATE TABLE statement
        String createTableQuery = "CREATE TABLE " + TABLE_NAME + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_TITLE + " TEXT NOT NULL, " +
                COL_DESCRIPTION + " TEXT NOT NULL, " +
                COL_CREATED_AT + " DATETIME DEFAULT CURRENT_TIMESTAMP)";
        
        // Execute the SQL statement
        db.execSQL(createTableQuery);
    }
    
    // Called when database version is upgraded
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop existing table and recreate
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
    
    /**
     * CREATE - Add a new task to database
     * @param title Task title
     * @param description Task description
     * @return true if insertion successful, false otherwise
     */
    public boolean addTask(String title, String description) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        
        // Put data into ContentValues
        contentValues.put(COL_TITLE, title);
        contentValues.put(COL_DESCRIPTION, description);
        
        // Insert data
        long result = db.insert(TABLE_NAME, null, contentValues);
        
        // Close database connection
        db.close();
        
        // If result is -1, insertion failed
        return result != -1;
    }
    
    /**
     * READ - Get all tasks from database
     * @return Cursor containing all tasks
     */
    public Cursor getAllTasks() {
        SQLiteDatabase db = this.getReadableDatabase();
        
        // SQL SELECT query - Get all columns, order by ID descending (newest first)
        String query = "SELECT * FROM " + TABLE_NAME + " ORDER BY " + COL_ID + " DESC";
        
        Cursor cursor = db.rawQuery(query, null);
        return cursor;
    }
    
    /**
     * UPDATE - Update an existing task
     * @param id Task ID to update
     * @param title New title
     * @param description New description
     * @return true if update successful, false otherwise
     */
    public boolean updateTask(int id, String title, String description) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        
        // Put updated data
        contentValues.put(COL_TITLE, title);
        contentValues.put(COL_DESCRIPTION, description);
        
        // Update query - WHERE clause
        int result = db.update(TABLE_NAME, contentValues, COL_ID + "=?", 
                              new String[]{String.valueOf(id)});
        
        db.close();
        
        // If result > 0, update successful
        return result > 0;
    }
    
    /**
     * DELETE - Delete a task from database
     * @param id Task ID to delete
     * @return true if deletion successful, false otherwise
     */
    public boolean deleteTask(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        
        // Delete query - WHERE clause
        int result = db.delete(TABLE_NAME, COL_ID + "=?", 
                              new String[]{String.valueOf(id)});
        
        db.close();
        
        return result > 0;
    }
    
    /**
     * Get task count
     * @return Number of tasks in database
     */
    public int getTaskCount() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT COUNT(*) FROM " + TABLE_NAME;
        Cursor cursor = db.rawQuery(query, null);
        
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        
        cursor.close();
        db.close();
        
        return count;
    }
    
    /**
     * Delete all tasks (optional - for testing)
     */
    public void deleteAllTasks() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, null, null);
        db.close();
    }
}

/**
 * INTERVIEW POINTS:
 * 
 * 1. SQLiteOpenHelper:
 *    - Abstract class that manages database creation and version management
 *    - onCreate() called once when database is created first time
 *    - onUpgrade() called when DATABASE_VERSION is increased
 * 
 * 2. ContentValues:
 *    - Key-value pairs for inserting/updating data
 *    - Type-safe way to work with database columns
 *    - Prevents SQL injection attacks
 * 
 * 3. Cursor:
 *    - Result set from database query
 *    - Like an iterator for database rows
 *    - Must be closed after use to prevent memory leaks
 * 
 * 4. Database Operations:
 *    - getWritableDatabase() - For INSERT, UPDATE, DELETE
 *    - getReadableDatabase() - For SELECT queries
 *    - Always close database connections after operations
 * 
 * 5. SQL Injection Prevention:
 *    - Used parameterized queries (?) instead of string concatenation
 *    - WHERE clause with String[] for safe parameter binding
 * 
 * 6. Error Handling:
 *    - Check return values (result != -1 for insert, result > 0 for update/delete)
 *    - Can add try-catch blocks for SQLiteException
 * 
 * WHY THIS APPROACH?
 * - Centralized database operations (Single Responsibility)
 * - Reusable across all activities
 * - Easy to maintain and test
 * - Follows Android best practices
 * 
 * POTENTIAL IMPROVEMENTS:
 * - Add try-catch blocks for exception handling
 * - Implement search functionality
 * - Add methods for filtering tasks
 * - Use transactions for bulk operations
 * - Implement database backup/restore
 */
