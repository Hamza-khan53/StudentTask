// SplashActivity.java - Splash screen (app launch screen)
// Package: com.example.studenttaskmanager

package com.example.studenttaskmanager;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;

/**
 * SplashActivity - Displays app logo/name for 2 seconds
 * Then automatically navigates to MainActivity
 * Set as launcher activity in AndroidManifest.xml
 */
public class SplashActivity extends AppCompatActivity {
    
    // Splash screen display duration (in milliseconds)
    private static final int SPLASH_DURATION = 2000; // 2 seconds
    
    /**
     * Called when activity is created
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Set content view to splash layout
        setContentView(R.layout.activity_splash);
        
        // Hide action bar (if any)
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        
        // Create Handler for delayed execution
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // Navigate to MainActivity after delay
                Intent intent = new Intent(SplashActivity.this, MainActivity.class);
                startActivity(intent);
                
                // Close SplashActivity so user can't go back to it
                finish();
            }
        }, SPLASH_DURATION);
    }
    
    /**
     * Prevent back button during splash screen
     * Optional but recommended
     */
    @Override
    public void onBackPressed() {
        // Do nothing - disable back button during splash
        // This prevents user from exiting app during splash
    }
}

/**
 * INTERVIEW POINTS:
 * 
 * 1. HANDLER AND postDelayed():
 *    - Handler schedules code to run on main UI thread
 *    - postDelayed() runs code after specified delay
 *    - Non-blocking - doesn't freeze the UI
 *    - Common pattern for timed operations
 * 
 * 2. WHY USE finish()?
 *    - Removes SplashActivity from back stack
 *    - User can't go back to splash screen
 *    - Pressing back in MainActivity exits app (not go to splash)
 *    - Good UX practice
 * 
 * 3. LAUNCHER ACTIVITY:
 *    - Set in AndroidManifest.xml with intent-filter:
 *    
 *    <activity android:name=".SplashActivity">
 *        <intent-filter>
 *            <action android:name="android.intent.action.MAIN" />
 *            <category android:name="android.intent.category.LAUNCHER" />
 *        </intent-filter>
 *    </activity>
 * 
 * 4. HIDING ACTION BAR:
 *    - Splash screen typically shows full-screen content
 *    - getSupportActionBar().hide() removes toolbar
 *    - Can also use NoActionBar theme in styles.xml
 * 
 * 5. DISABLING BACK BUTTON:
 *    - Override onBackPressed() with empty implementation
 *    - Prevents user from exiting during splash
 *    - Optional but improves UX
 * 
 * ALTERNATIVE APPROACHES:
 * 
 * 1. Thread.sleep() (NOT RECOMMENDED):
 *    try {
 *        Thread.sleep(2000);
 *    } catch (InterruptedException e) {
 *        e.printStackTrace();
 *    }
 *    - Blocks UI thread
 *    - Makes app unresponsive
 *    - Bad practice
 * 
 * 2. CountDownTimer:
 *    new CountDownTimer(2000, 1000) {
 *        public void onTick(long millisUntilFinished) {}
 *        public void onFinish() {
 *            // Navigate to MainActivity
 *        }
 *    }.start();
 *    - More code for same result
 *    - Useful if you need to show countdown
 * 
 * 3. AnimationListener:
 *    - If splash has animation
 *    - Navigate after animation completes
 *    - Better UX for animated splashes
 * 
 * 4. Modern Approach - Splash Screen API (Android 12+):
 *    - Use SplashScreen API from androidx.core
 *    - Standardized splash screen behavior
 *    - Better performance
 *    - Handles theme transitions smoothly
 * 
 * BEST PRACTICES:
 * - Keep splash duration short (1-2 seconds)
 * - Don't use splash for heavy initialization (bad UX)
 * - Use splash time for minimal setup only
 * - Consider removing splash entirely for fast apps
 * - For long startup tasks, show progress indicator instead
 * 
 * POTENTIAL IMPROVEMENTS:
 * - Add fade-in/fade-out animation
 * - Show app version number
 * - Check for updates during splash
 * - Check internet connectivity
 * - Load initial data from database
 * - Implement splash screen theming
 * - Add animated logo
 * 
 * COMMON MISTAKES TO AVOID:
 * - Heavy operations on main thread during splash
 * - Splash duration too long (annoying for users)
 * - Not calling finish() (user can go back to splash)
 * - Using Thread.sleep() instead of Handler
 * - Not handling configuration changes (rotation)
 * 
 * WHY SPLASH SCREENS?
 * - Professional look
 * - Brand visibility
 * - Mask initial loading time
 * - Smooth app launch experience
 * - Industry standard for mobile apps
 */
