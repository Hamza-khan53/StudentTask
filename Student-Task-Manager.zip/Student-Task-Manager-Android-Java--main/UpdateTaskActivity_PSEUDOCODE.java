// UpdateTaskActivity.java - Edit existing task screen
// Package: com.example.studenttaskmanager

package com.example.studenttaskmanager;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

/**
 * UpdateTaskActivity - Screen for editing existing tasks
 * Pre-fills form with existing task data
 */
public class UpdateTaskActivity extends AppCompatActivity {
    
    // UI Components
    private TextInputLayout titleInputLayout;
    private TextInputLayout descriptionInputLayout;
    private TextInputEditText titleEditText;
    private TextInputEditText descriptionEditText;
    private Button buttonUpdate;
    private Toolbar toolbar;
    
    // Database helper
    private DBHelper dbHelper;
    
    // Task data received from intent
    private int taskId;
    private String taskTitle;
    private String taskDescription;
    
    /**
     * Called when activity is created
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_task);
        
        // Initialize database helper
        dbHelper = new DBHelper(this);
        
        // Initialize views
        initializeViews();
        
        // Setup toolbar
        setupToolbar();
        
        // Receive data from intent
        receiveIntentData();
        
        // Pre-fill form with existing data
        populateFormData();
        
        // Setup update button click listener
        buttonUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateTask();
            }
        });
    }
    
    /**
     * Initialize all views
     */
    private void initializeViews() {
        toolbar = findViewById(R.id.toolbar);
        titleInputLayout = findViewById(R.id.titleInputLayout);
        descriptionInputLayout = findViewById(R.id.descriptionInputLayout);
        titleEditText = findViewById(R.id.editTextTitle);
        descriptionEditText = findViewById(R.id.editTextDescription);
        buttonUpdate = findViewById(R.id.buttonUpdate);
    }
    
    /**
     * Setup toolbar with back navigation
     */
    private void setupToolbar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Edit Task");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    
    /**
     * Handle back button in toolbar
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    
    /**
     * Receive task data from Intent extras
     */
    private void receiveIntentData() {
        Intent intent = getIntent();
        
        // Check if intent has required data
        if (intent != null) {
            taskId = intent.getIntExtra("task_id", -1);
            taskTitle = intent.getStringExtra("task_title");
            taskDescription = intent.getStringExtra("task_description");
            
            // Validate received data
            if (taskId == -1) {
                Toast.makeText(this, "Error: Invalid task data", 
                              Toast.LENGTH_SHORT).show();
                finish(); // Close activity if data is invalid
            }
        } else {
            Toast.makeText(this, "Error: No task data received", 
                          Toast.LENGTH_SHORT).show();
            finish();
        }
    }
    
    /**
     * Pre-fill form fields with existing task data
     */
    private void populateFormData() {
        if (taskTitle != null && taskDescription != null) {
            titleEditText.setText(taskTitle);
            descriptionEditText.setText(taskDescription);
            
            // Optional: Set cursor to end of text
            titleEditText.setSelection(taskTitle.length());
        }
    }
    
    /**
     * Validate input and update task in database
     */
    private void updateTask() {
        // Get updated values
        String updatedTitle = titleEditText.getText().toString().trim();
        String updatedDescription = descriptionEditText.getText().toString().trim();
        
        // Reset errors
        titleInputLayout.setError(null);
        descriptionInputLayout.setError(null);
        
        // Validate title
        if (updatedTitle.isEmpty()) {
            titleInputLayout.setError("Title is required");
            titleEditText.requestFocus();
            return;
        }
        
        if (updatedTitle.length() < 3) {
            titleInputLayout.setError("Title must be at least 3 characters");
            titleEditText.requestFocus();
            return;
        }
        
        // Validate description
        if (updatedDescription.isEmpty()) {
            descriptionInputLayout.setError("Description is required");
            descriptionEditText.requestFocus();
            return;
        }
        
        if (updatedDescription.length() < 5) {
            descriptionInputLayout.setError("Description must be at least 5 characters");
            descriptionEditText.requestFocus();
            return;
        }
        
        // Check if data actually changed
        if (updatedTitle.equals(taskTitle) && 
            updatedDescription.equals(taskDescription)) {
            Toast.makeText(this, "No changes made", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        
        // Update in database
        boolean isUpdated = dbHelper.updateTask(taskId, updatedTitle, updatedDescription);
        
        if (isUpdated) {
            // Show success message
            Toast.makeText(this, "Task updated successfully!", 
                          Toast.LENGTH_SHORT).show();
            
            // Close activity and return to MainActivity
            finish();
        } else {
            // Show error message
            Toast.makeText(this, "Failed to update task. Please try again.", 
                          Toast.LENGTH_SHORT).show();
        }
    }
}

/**
 * INTERVIEW POINTS:
 * 
 * 1. INTENT DATA PASSING:
 *    - putExtra() in source activity (MainActivity)
 *    - getIntent() in destination activity
 *    - getIntExtra(), getStringExtra() to retrieve data
 *    - Type-safe data transfer between activities
 * 
 * 2. DATA VALIDATION BEFORE USE:
 *    - Check if intent is not null
 *    - Check if ID is valid (not -1)
 *    - Prevent crashes from invalid data
 *    - Close activity if data is corrupted
 * 
 * 3. PRE-FILLING FORM DATA:
 *    - setText() to populate EditText fields
 *    - setSelection() to position cursor
 *    - Better UX - user sees existing data
 *    - Easy to modify without retyping everything
 * 
 * 4. CHANGE DETECTION:
 *    - Compare new values with original values
 *    - Don't update if nothing changed
 *    - Saves unnecessary database operations
 *    - Informs user of "No changes made"
 * 
 * 5. REUSABILITY:
 *    - Similar validation logic to AddTaskActivity
 *    - Could create a base class or utility methods
 *    - Good candidate for refactoring
 * 
 * 6. ERROR HANDLING:
 *    - Handle invalid intent data gracefully
 *    - Don't crash the app
 *    - Provide feedback and close cleanly
 * 
 * WHY SEPARATE ADD AND UPDATE ACTIVITIES?
 * - Clear separation of concerns
 * - Different toolbar titles and button text
 * - Different validation requirements (can compare with original)
 * - Easier to maintain and test
 * - Alternative: Single activity with mode flag
 * 
 * DATA PASSING ALTERNATIVES:
 * 1. Intent Extras (current approach)
 *    - Simple, direct
 *    - Limited to primitive types and Parcelable/Serializable
 *    - Good for small amounts of data
 * 
 * 2. Parcelable/Serializable
 *    - Pass entire TaskModel object
 *    - TaskModel implements Parcelable
 *    - Cleaner code, but more setup
 * 
 * 3. ViewModel (Modern approach)
 *    - Shared ViewModel between activities
 *    - Survives configuration changes
 *    - Part of Android Architecture Components
 * 
 * 4. Database Query
 *    - Pass only task ID
 *    - Query database in UpdateTaskActivity
 *    - Single source of truth
 *    - More database queries but cleaner intent
 * 
 * POTENTIAL IMPROVEMENTS:
 * - Pass only task ID, query database for latest data
 * - Show "Unsaved changes" dialog on back press
 * - Add timestamp for "Last updated"
 * - Implement undo functionality
 * - Show update history/changelog
 * - Add "Delete" button in update screen
 * - Disable update button if no changes detected
 */
